# PaysenP – Application mobile (Flutter)

Application mobile PaysenP : connexion, tableau de bord, cartes virtuelles (dépôt / retrait / détails / transactions), boutique et profil.
API : `https://paysenp.com/api/v1` (URL dans `lib/api_endpoints.dart`).

## Compiler l'APK sur GitHub (sans installer Flutter)
1. Poussez ce dépôt sur GitHub (branche `main`).
2. Onglet **Actions** → workflow **Build APK** (se lance à chaque push, ou bouton *Run workflow*).
3. À la fin, téléchargez l'artefact **paysenp-apk** → `app-release.apk`.

## Lancer en local
```bash
flutter create . --org com.paysenp --project-name paysenp
flutter pub get
flutter run
```

## Structure
- `lib/main.dart` : interface (Connexion, Accueil, Cartes, Boutique, Profil)
- `lib/paysenp_api.dart` : client HTTP + modèles
- `lib/api_endpoints.dart` : toutes les URL de l'API

## Sécurité
Ne jamais enregistrer le numéro de carte ni le CVV sur le disque ni dans les logs. Ne commitez jamais de clés (`key.properties`, `*.jks`).
