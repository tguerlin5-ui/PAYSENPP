// PaysenP - kouch API + modèl. Tout fòma yo soti nan vrè repons sèvè a.
// Depandans: dio  (flutter pub add dio)
// Mete api_endpoints.dart nan menm dosye a.
import 'package:dio/dio.dart';
import 'api_endpoints.dart';

// ---------- Èd pou li nimewo san TypeError ----------
double toD(dynamic v) => v == null ? 0.0 : (v is num ? v.toDouble() : double.tryParse(v.toString()) ?? 0.0);
int toI(dynamic v) => v == null ? 0 : (v is num ? v.toInt() : int.tryParse(v.toString()) ?? 0);
String toS(dynamic v) => v?.toString() ?? '';

/// Imaj boutik: chemen relatif -> URL konplè (bezwen /storage/)
String shopImageUrl(String? path) {
  if (path == null || path.isEmpty) return '';
  if (path.startsWith('http')) return path;
  return 'https://paysenp.com/storage/${path.startsWith('/') ? path.substring(1) : path}';
}

class ApiException implements Exception {
  final String message;
  final int? status;
  ApiException(this.message, [this.status]);
  @override
  String toString() => message;
}

// ---------- Kliyan HTTP ----------
class ApiClient {
  ApiClient._();
  static final ApiClient I = ApiClient._();

  String? token; // mete l apre login (sove l nan flutter_secure_storage)

  final Dio _dio = Dio(BaseOptions(
    connectTimeout: const Duration(seconds: 20),
    receiveTimeout: const Duration(seconds: 30),
    headers: {'Accept': 'application/json'},
    validateStatus: (s) => s != null && s < 600,
  ));

  Options get _opts => Options(headers: {if (token != null) 'Authorization': 'Bearer $token'});

  /// Li 3 fòma repons yo epi retounen `data`, oswa voye ApiException.
  dynamic _unwrap(Response r) {
    final b = r.data;
    if (r.statusCode == 401) throw ApiException('Sesyon fini. Konekte ankò.', 401);
    if (b is! Map) throw ApiException('Repons envalid', r.statusCode);
    // Fòma 4 (Laravel 422): {message:"..", errors:{champ:[..]}}
    if (b['errors'] is Map) {
      final all = <String>[];
      (b['errors'] as Map).forEach((k, v) => all.addAll(v is List ? v.map((e) => e.toString()) : [v.toString()]));
      throw ApiException(all.isEmpty ? toS(b['message']) : all.join('\n'), r.statusCode);
    }
    // Fòma 1: {message:{success:[..]|error:[..]}, data, type}
    if (b['message'] is Map) {
      final m = b['message'] as Map;
      if (b['type'] == 'error' || m['error'] != null) {
        final e = m['error'];
        throw ApiException(e is List ? e.join('\n') : toS(e), r.statusCode);
      }
      return b['data'];
    }
    // Fòma 2 (boutik): {success:true|false, data}
    if (b.containsKey('success') && b['success'] is bool) {
      if (b['success'] != true) throw ApiException(toS(b['message']), r.statusCode);
      return b['data'];
    }
    // Fòma 3: {status:false, message:"..."}
    if (b['status'] == false) throw ApiException(toS(b['message']), r.statusCode);
    return b['data'] ?? b;
  }

  Future<dynamic> get(String url, {Map<String, dynamic>? q}) async =>
      _unwrap(await _dio.get(url, queryParameters: q, options: _opts));

  Future<dynamic> post(String url, {Map<String, dynamic>? body}) async => _unwrap(
      await _dio.post(url, data: body, options: _opts.copyWith(contentType: Headers.jsonContentType)));

  // ----- Auth -----
  Future<AppUser> login(String credentials, String password) async {
    final d = await post(ApiEndpoints.login, body: {'credentials': credentials, 'password': password});
    token = toS(d['token']);
    return AppUser.fromJson(Map<String, dynamic>.from(d['user_info']));
  }

  Future<void> logout() async {
    try {
      await post(ApiEndpoints.logout);
    } finally {
      token = null;
    }
  }

  // ----- Dashboard -----
  Future<Dashboard> dashboard() async =>
      Dashboard.fromJson(Map<String, dynamic>.from(await get(ApiEndpoints.dashboard)));

  // ----- Boutik -----
  Future<List<Product>> products() async {
    final l = await get(ApiEndpoints.shopProducts);
    return List<Product>.from((l as List).map((x) => Product.fromJson(Map<String, dynamic>.from(x))));
  }

  Future<Product> product(int id) async =>
      Product.fromJson(Map<String, dynamic>.from(await get(ApiEndpoints.shopProduct(id))));

  // ----- Kat vityèl (nouvo wout) -----
  static const _vc = '${ApiEndpoints.base}/user/virtual-card';

  // Pwoteksyon kont double-tap: yon sèl operasyon kat alafwa nan app la.
  // (Sèvè a gen tou yon lock pa itilizatè ki reponn 429 si de demann rive ansanm.)
  bool _cardBusy = false;

  Future<T> _cardOp<T>(Future<T> Function() fn) async {
    if (_cardBusy) throw ApiException('Yon operasyon ap fèt deja. Tann yon ti moman.');
    _cardBusy = true;
    try {
      return await fn();
    } finally {
      _cardBusy = false;
    }
  }

  Map<String, dynamic> _cardBody(int cardId, double amount, String walletCurrency) =>
      {'card_id': cardId, 'amount': amount, 'wallet_currency': walletCurrency};

  /// Previzyon depo: PA deplase lajan. `cardId` = VCard.id (nimerik), pa `ref`.
  Future<CardPreview> cardDepositPreview(int cardId, double amount, {String walletCurrency = 'USD'}) async {
    final d = await post(ApiEndpoints.vcDepositPreview, body: _cardBody(cardId, amount, walletCurrency));
    return CardPreview.fromJson(Map<String, dynamic>.from(d['preview']));
  }

  /// Previzyon retrè: PA deplase lajan. Limit min $5 (sèvè a verifye l).
  Future<CardPreview> cardWithdrawPreview(int cardId, double amount, {String walletCurrency = 'USD'}) async {
    final d = await post(ApiEndpoints.vcWithdrawPreview, body: _cardBody(cardId, amount, walletCurrency));
    return CardPreview.fromJson(Map<String, dynamic>.from(d['preview']));
  }

  /// DEPO REYÈL: debite wallet la, kredite kat la. Montre yon dyalòg konfirmasyon anvan w rele l.
  /// Erè posib: "Service temporairement indisponible" (Maplerad pa gen lajan),
  /// "Wallet Balance Is Insufficient", 429 (yon operasyon deja an kou).
  Future<CardTxResult> cardDeposit(int cardId, double amount, {String walletCurrency = 'USD'}) =>
      _cardOp(() async {
        final d = await post(ApiEndpoints.vcDeposit, body: _cardBody(cardId, amount, walletCurrency));
        return CardTxResult.fromJson(Map<String, dynamic>.from(d));
      });

  /// RETRÈ REYÈL: retire lajan sou kat la, kredite wallet la. Min $5.
  Future<CardTxResult> cardWithdraw(int cardId, double amount, {String walletCurrency = 'USD'}) =>
      _cardOp(() async {
        final d = await post(ApiEndpoints.vcWithdraw, body: _cardBody(cardId, amount, walletCurrency));
        return CardTxResult.fromJson(Map<String, dynamic>.from(d));
      });

  Future<List<VCard>> cards() async {
    final d = await get(_vc);
    return List<VCard>.from((d['cards'] as List).map((x) => VCard.fromJson(Map<String, dynamic>.from(x))));
  }

  /// Mande modpas. Pa janm sove nimewo kat / CVV sou disk oswa nan log.
  Future<VCardDetails> cardDetails(String ref, String password) async {
    final d = await post('$_vc/$ref/details', body: {'password': password});
    return VCardDetails.fromJson(Map<String, dynamic>.from(d['card']));
  }

  Future<List<VCardTx>> cardTransactions(String ref) async {
    final d = await get('$_vc/$ref/transactions');
    final t = d['transactions'];
    final list = t is Map ? (t['transactions'] as List? ?? []) : (t as List? ?? []);
    return List<VCardTx>.from(list.map((x) => VCardTx.fromJson(Map<String, dynamic>.from(x))));
  }
}

// ---------- Modèl ----------
class AppUser {
  final int id;
  final String fullname, email, username;
  final int kycVerified; // 0 default, 1 apwouve, 2 annatant, 3 rejte
  AppUser({required this.id, required this.fullname, required this.email, required this.username, required this.kycVerified});
  factory AppUser.fromJson(Map<String, dynamic> j) => AppUser(
        id: toI(j['id']),
        fullname: toS(j['fullname']),
        email: toS(j['email']),
        username: toS(j['username']),
        kycVerified: toI(j['kyc_verified']),
      );
}

class Wallet {
  final double balance;
  final String code; // USD
  Wallet(this.balance, this.code);
  factory Wallet.fromJson(Map<String, dynamic> j) =>
      Wallet(toD(j['balance']), toS((j['currency'] as Map?)?['code']));
}

class Tx {
  final String type, trxId, currency;
  final double amount, totalCharge, payable;
  final int status; // 1 Success, 2 Pending, 3 Hold, 4 Rejected, 5 Waiting
  final DateTime? createdAt;
  Tx({required this.type, required this.trxId, required this.currency, required this.amount,
      required this.totalCharge, required this.payable, required this.status, this.createdAt});
  factory Tx.fromJson(Map<String, dynamic> j) => Tx(
        type: toS(j['type']),
        trxId: toS(j['trx_id']),
        currency: toS(j['request_currency']),
        amount: toD(j['request_amount']),
        totalCharge: toD(j['total_charge']),
        payable: toD(j['total_payable']),
        status: toI(j['status']),
        createdAt: DateTime.tryParse(toS(j['created_at']))?.toLocal(),
      );
}

class Dashboard {
  final AppUser user;
  final List<Wallet> wallets;
  final List<Tx> recent;
  Dashboard(this.user, this.wallets, this.recent);
  Wallet? get main => wallets.isEmpty ? null : wallets.first;
  factory Dashboard.fromJson(Map<String, dynamic> j) => Dashboard(
        AppUser.fromJson(Map<String, dynamic>.from(j['user_info'])),
        List<Wallet>.from(((j['user_wallets'] ?? []) as List).map((x) => Wallet.fromJson(Map<String, dynamic>.from(x)))),
        List<Tx>.from(((j['recent_transactions'] ?? []) as List).map((x) => Tx.fromJson(Map<String, dynamic>.from(x)))),
      );
}

class Variant {
  final int id, stock;
  final String size, color;
  final double price;
  Variant({required this.id, required this.stock, required this.size, required this.color, required this.price});
  factory Variant.fromJson(Map<String, dynamic> j) => Variant(
        id: toI(j['id']), stock: toI(j['stock']), size: toS(j['size']), color: toS(j['color']), price: toD(j['price']));
}

class Product {
  final int id, totalStock;
  final String name, description, category, image;
  final double price, oldPrice;
  final List<String> images;
  final List<Variant> variants;
  Product({required this.id, required this.totalStock, required this.name, required this.description,
      required this.category, required this.image, required this.price, required this.oldPrice,
      required this.images, required this.variants});
  factory Product.fromJson(Map<String, dynamic> j) {
    final imgs = List<String>.from(((j['images'] ?? []) as List)
        .map((x) => shopImageUrl(toS((x as Map)['image_path']))));
    final main = shopImageUrl(toS(j['main_image']));
    return Product(
      id: toI(j['id']),
      totalStock: toI(j['total_stock']),
      name: toS(j['name']),
      description: toS(j['description']),
      category: toS(j['category']),
      image: main.isNotEmpty ? main : (imgs.isNotEmpty ? imgs.first : ''),
      price: toD(j['price']),
      oldPrice: toD(j['old_price']),
      images: imgs,
      variants: List<Variant>.from(((j['variants'] ?? []) as List).map((x) => Variant.fromJson(Map<String, dynamic>.from(x)))),
    );
  }
}

class VCard {
  final int id;
  final String ref, last4, maskedPan, currency, status, provider;
  final double balance;
  VCard({required this.id, required this.ref, required this.last4, required this.maskedPan,
      required this.currency, required this.status, required this.provider, required this.balance});
  bool get enabled => status == 'ENABLED';
  factory VCard.fromJson(Map<String, dynamic> j) => VCard(
        id: toI(j['id']), ref: toS(j['ref']), last4: toS(j['last_4']), maskedPan: toS(j['masked_pan']),
        currency: toS(j['currency']), status: toS(j['status']), provider: toS(j['provider']), balance: toD(j['balance']));
}

class VCardDetails {
  final String ref, name, number, cvv, expiry, last4, currency, brand;
  final double balance;
  final bool active;
  VCardDetails({required this.ref, required this.name, required this.number, required this.cvv,
      required this.expiry, required this.last4, required this.currency, required this.brand,
      required this.balance, required this.active});
  /// 4 chif pa 4 chif: "4288 5200 1234 5241"
  String get spacedNumber => number.replaceAllMapped(RegExp(r'.{4}'), (m) => '${m.group(0)} ').trim();
  factory VCardDetails.fromJson(Map<String, dynamic> j) => VCardDetails(
        ref: toS(j['ref']), name: toS(j['name']), number: toS(j['card_number']), cvv: toS(j['cvv']),
        expiry: toS(j['expiry']), last4: toS(j['last_4']), currency: toS(j['currency']), brand: toS(j['brand']),
        balance: toD(j['balance']), active: j['is_active'] == true);
}

class CardPreview {
  final double amount, totalCharge, payable;
  final String fromCurrency, cardCurrency;
  CardPreview({required this.amount, required this.totalCharge, required this.payable,
      required this.fromCurrency, required this.cardCurrency});
  factory CardPreview.fromJson(Map<String, dynamic> j) => CardPreview(
        amount: toD(j['amount']), totalCharge: toD(j['total_charge']), payable: toD(j['payable']),
        fromCurrency: toS(j['from_currency']), cardCurrency: toS(j['card_currency']));
}

class CardTxResult {
  final String trxId;
  final double cardBalance;
  CardTxResult({required this.trxId, required this.cardBalance});
  factory CardTxResult.fromJson(Map<String, dynamic> j) =>
      CardTxResult(trxId: toS(j['trx_id']), cardBalance: toD(j['card_balance']));
}

class VCardTx {
  final String id, description, status, entry, type, merchant;
  final double amount; // deja an dola (santim / 100)
  final DateTime? createdAt;
  VCardTx({required this.id, required this.description, required this.status, required this.entry,
      required this.type, required this.merchant, required this.amount, this.createdAt});
  bool get isDebit => entry == 'DEBIT';
  factory VCardTx.fromJson(Map<String, dynamic> j) => VCardTx(
        id: toS(j['id']), description: toS(j['description']), status: toS(j['status']),
        entry: toS(j['entry']), type: toS(j['type']),
        merchant: toS((j['merchant'] as Map?)?['name']),
        amount: toD(j['amount']) / 100, // Maplerad bay santim
        createdAt: DateTime.tryParse(toS(j['created_at'])));
}
