/// Tout URL yo soti dirèkteman nan `php artisan route:list --path=api/v1`.
/// Pa devine okenn URL: si yon wout pa la, li pa egziste sou sèvè a.
class ApiEndpoints {
  static const String base = 'https://paysenp.com/api/v1';

  // ---------- Settings (pa mande token) ----------
  static const String basicSettings = '$base/settings/basic-settings'; // GET
  static const String languages = '$base/settings/languages'; // GET
  static const String onboardScreens = '$base/settings/onboard-screens'; // GET
  static const String splashScreen = '$base/settings/splash-screen'; // GET

  // ---------- Auth (pa mande token) ----------
  static const String login = '$base/login'; // POST  (champ: credentials, password)
  static const String register = '$base/register'; // POST

  // Forgot password
  static const String forgotFindUser = '$base/password/forgot/find/user'; // POST
  static const String forgotVerifyCode = '$base/password/forgot/verify/code'; // POST
  static const String forgotResendCode = '$base/password/forgot/resend/code'; // GET
  static const String forgotReset = '$base/password/forgot/reset'; // POST

  // ---------- OTP / KYC / 2FA (token) ----------
  static const String mailSendCode = '$base/authorize/mail/send/code'; // GET
  static const String mailResendCode = '$base/authorize/mail/resend/code'; // GET
  static const String mailVerifyCode = '$base/authorize/mail/verify/code'; // POST
  static const String kycInputFields = '$base/authorize/kyc/input-fields'; // GET
  static const String kycSubmit = '$base/authorize/kyc/submit'; // POST (multipart)
  static const String google2faStatus = '$base/authorize/google/2fa/status'; // GET
  static const String google2faUpdate = '$base/authorize/google/2fa/status-update'; // POST
  static const String google2faVerify = '$base/authorize/google/2fa/verify'; // POST

  // ---------- Dashboard / Profile (token) ----------
  static const String dashboard = '$base/user/dashboard'; // GET
  static const String notifications = '$base/user/notifications'; // GET
  static const String profileInfo = '$base/user/profile/info'; // GET
  static const String profileUpdate = '$base/user/profile/info/update'; // POST
  static const String passwordUpdate = '$base/user/profile/password/update'; // POST
  static const String deleteAccount = '$base/user/profile/delete-account'; // POST
  static const String logout = '$base/user/logout'; // POST

  // ---------- Transaction History (token) ----------
  static const String transactionLog = '$base/user/transaction/log'; // GET

  // ---------- Add Money (token) ----------
  static const String addMoneyGateways = '$base/user/add-money/payment-gateways'; // GET
  static const String addMoneyGatewayFields = '$base/user/add-money/payment-gateway/additional-fields'; // GET
  static const String addMoneyPreview = '$base/user/add-money/preview'; // POST
  static const String addMoneyAutomatic = '$base/user/add-money/automatic/submit'; // POST
  static const String addMoneyManualFields = '$base/user/add-money/manual/input-fields'; // GET
  static const String addMoneyManual = '$base/user/add-money/manual/submit'; // POST
  static const String addMoneyAuthorizePay = '$base/user/add-money/authorize-payment-submit'; // POST
  static String addMoneyRedirect(String gateway) => '$base/user/add-money/redirect/btn/checkout/$gateway'; // GET
  static String addMoneySuccess(String gateway) => '$base/user/add-money/success/response/$gateway'; // GET/POST
  static String addMoneyCancel(String gateway) => '$base/user/add-money/cancel/response/$gateway'; // GET/POST
  static String addMoneyCryptoConfirm(String trxId) => '$base/user/add-money/payment/crypto/confirm/$trxId'; // POST

  // ---------- Transfer (token) ----------
  static const String transferWallets = '$base/user/money-transfer/wallets'; // GET
  static const String transferCheckUser = '$base/user/money-transfer/exist'; // POST
  static const String transferPreview = '$base/user/money-transfer/preview'; // POST
  static const String transferSubmit = '$base/user/money-transfer/submit'; // POST

  // ---------- Money Exchange (token) ----------
  static const String exchangeWallets = '$base/user/money-exchange/wallets'; // GET
  static const String exchangePreview = '$base/user/money-exchange/preview'; // POST
  static const String exchangeSubmit = '$base/user/money-exchange/submit'; // POST

  // ---------- Withdraw (token) ----------
  static const String withdrawWalletGateways = '$base/user/withdraw/wallet-gateways'; // GET
  static const String withdrawFields = '$base/user/withdraw/gateway/input-fields'; // GET
  static const String withdrawPreview = '$base/user/withdraw/preview'; // POST
  static const String withdrawSubmit = '$base/user/withdraw/submit'; // POST

  // ---------- Virtual Card (Maplerad) - ITILIZE SA YO (token) ----------
  static const String vcList = '$base/user/virtual-card'; // GET  -> data.cards[]
  static String vcDetails(String ref) => '$base/user/virtual-card/$ref/details'; // POST {password}
  static String vcTransactions(String ref) => '$base/user/virtual-card/$ref/transactions'; // GET
  static const String vcDepositPreview = '$base/user/virtual-card/deposit/preview'; // POST {card_id (nimerik), amount, wallet_currency}
  static const String vcWithdrawPreview = '$base/user/virtual-card/withdraw/preview'; // POST (min $5)
  static const String vcDeposit = '$base/user/virtual-card/deposit'; // POST -> {trx_id, card_balance}. 429 si yon lòt operasyon an kou
  static const String vcWithdraw = '$base/user/virtual-card/withdraw'; // POST -> {trx_id, card_balance}. Min $5, 429 si lock

  // ---------- ANSYEN wout Cardyfie: bay 404, PA ITILIZE ----------
  static const String cardIndex = '$base/user/cardyfie-card'; // GET
  static const String cardDetails = '$base/user/cardyfie-card/details'; // GET
  static const String cardCreateInfo = '$base/user/cardyfie-card/create/info'; // GET
  static const String cardCreate = '$base/user/cardyfie-card/create'; // POST
  static const String cardCreateCustomer = '$base/user/cardyfie-card/create/customer'; // POST (multipart)
  static const String cardEditCustomerPage = '$base/user/cardyfie-card/edit/customer/page'; // GET
  static const String cardUpdateCustomer = '$base/user/cardyfie-card/update/customer'; // POST
  static const String cardDeposit = '$base/user/cardyfie-card/deposit'; // POST
  static const String cardWithdraw = '$base/user/cardyfie-card/withdraw'; // POST
  static const String cardChangeStatus = '$base/user/cardyfie-card/change/status'; // POST (freeze/unfreeze)
  static const String cardClose = '$base/user/cardyfie-card/close'; // POST
  static const String cardTransactions = '$base/user/cardyfie-card/transaction'; // GET
  static const String cardTrxLimit = '$base/user/cardyfie-card/trx-limit'; // GET

  // ---------- Shop / Julie Store (token) ----------
  // Panye (cart) pa gen wout sèvè: li rete lokal nan app la.
  static const String shopProducts = '$base/user/julie-store/products'; // GET
  static String shopProduct(int id) => '$base/user/julie-store/products/$id'; // GET (variants)
  static const String shopDeliveryZones = '$base/user/julie-store/delivery-zones'; // GET
  static const String shopCheckoutPreview = '$base/user/julie-store/checkout/preview'; // POST
  static const String shopCreateOrder = '$base/user/julie-store/orders'; // POST
  static const String shopOrders = '$base/user/julie-store/orders'; // GET
  static String shopOrder(int id) => '$base/user/julie-store/orders/$id'; // GET

  // ---------- Subscription (token) ----------
  static const String subInfo = '$base/user/subscription/info'; // GET
  static const String subPurchase = '$base/user/subscription/purchase'; // POST
  static const String subUpgrade = '$base/user/subscription/upgrade'; // POST
  static const String subCancel = '$base/user/subscription/cancel'; // POST
}
