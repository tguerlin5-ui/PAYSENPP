import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'paysenp_api.dart';

const kNavy = Color(0xFF0B1437), kAccent = Color(0xFF00C2A8), kBg = Color(0xFFF4F6FB);
const _store = FlutterSecureStorage();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  ApiClient.I.token = await _store.read(key: 'token');
  runApp(const PaysenpApp());
}

// ---------- Utilitaires ----------
String money(double v, [String c = 'USD']) => '${v.toStringAsFixed(2)} $c';
String two(int n) => n.toString().padLeft(2, '0');
String fmtDate(DateTime? d) => d == null ? '' : '${two(d.day)}/${two(d.month)}/${d.year}';
String pretty(String s) {
  final t = s.replaceAll(RegExp(r'[-_]'), ' ').trim();
  return t.isEmpty ? 'Transaction' : t[0].toUpperCase() + t.substring(1).toLowerCase();
}

String errMsg(Object e) => e is ApiException ? e.message : 'Connexion impossible. Vérifiez votre réseau.';

void toast(BuildContext c, String m, {bool error = false}) => ScaffoldMessenger.of(c)
  ..hideCurrentSnackBar()
  ..showSnackBar(SnackBar(
      content: Text(m),
      backgroundColor: error ? Colors.red.shade700 : kNavy,
      behavior: SnackBarBehavior.floating));

(String, Color) txStatus(int s) => switch (s) {
      1 => ('Réussi', Colors.green),
      2 || 5 => ('En attente', Colors.orange),
      3 => ('Suspendu', Colors.blueGrey),
      4 => ('Rejeté', Colors.red),
      _ => ('—', Colors.grey),
    };

Future<void> signOut(BuildContext c) async {
  try {
    await ApiClient.I.logout();
  } catch (_) {}
  ApiClient.I.token = null;
  await _store.delete(key: 'token');
  if (c.mounted) {
    Navigator.of(c).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false);
  }
}

Widget bigBtn(String label, VoidCallback? onTap, {bool busy = false}) => SizedBox(
      width: double.infinity,
      height: 52,
      child: FilledButton(
        onPressed: busy ? null : onTap,
        child: busy
            ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white))
            : Text(label, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
      ),
    );

// ---------- Application ----------
class PaysenpApp extends StatelessWidget {
  const PaysenpApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'PaysenP',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: kNavy, primary: kNavy, secondary: kAccent),
          scaffoldBackgroundColor: kBg,
          appBarTheme: const AppBarTheme(backgroundColor: kBg, elevation: 0, foregroundColor: kNavy),
          navigationBarTheme: const NavigationBarThemeData(backgroundColor: Colors.white, indicatorColor: Color(0x3300C2A8)),
          inputDecorationTheme: InputDecorationTheme(
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none)),
          filledButtonTheme: FilledButtonThemeData(
              style: FilledButton.styleFrom(
                  backgroundColor: kNavy, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)))),
        ),
        home: ApiClient.I.token == null ? const LoginPage() : const Shell(),
      );
}

// ---------- Chargeur générique (chargement / erreur / réessayer) ----------
class Load<T> extends StatefulWidget {
  final Future<T> Function() fetch;
  final Widget Function(BuildContext, T, Future<void> Function()) build;
  const Load({super.key, required this.fetch, required this.build});
  @override
  State<Load<T>> createState() => _LoadState<T>();
}

class _LoadState<T> extends State<Load<T>> {
  late Future<T> _f = widget.fetch();

  Future<void> _reload() async {
    final n = widget.fetch();
    setState(() => _f = n);
    try {
      await n;
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<T>(
        future: _f,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) {
            return const Padding(padding: EdgeInsets.all(32), child: Center(child: CircularProgressIndicator()));
          }
          if (s.hasError) {
            final e = s.error;
            final auth = e is ApiException && e.status == 401;
            return Center(
                child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.cloud_off, size: 48, color: Colors.grey),
                      const SizedBox(height: 12),
                      Text(errMsg(e!), textAlign: TextAlign.center),
                      const SizedBox(height: 16),
                      FilledButton(
                          onPressed: auth ? () => signOut(context) : _reload,
                          child: Text(auth ? 'Se reconnecter' : 'Réessayer')),
                    ])));
          }
          return widget.build(c, s.data as T, _reload);
        },
      );
}

// ---------- Connexion ----------
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _u = TextEditingController(), _p = TextEditingController();
  bool _busy = false, _hide = true;

  Future<void> _go() async {
    if (_u.text.trim().isEmpty || _p.text.isEmpty) {
      toast(context, 'Renseignez vos identifiants', error: true);
      return;
    }
    setState(() => _busy = true);
    try {
      await ApiClient.I.login(_u.text.trim(), _p.text);
      await _store.write(key: 'token', value: ApiClient.I.token);
      if (!mounted) return;
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const Shell()));
    } catch (e) {
      if (mounted) toast(context, errMsg(e), error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: kNavy,
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(28),
              child: Column(children: [
                const Icon(Icons.account_balance_wallet_rounded, size: 64, color: kAccent),
                const SizedBox(height: 12),
                const Text('PaysenP', style: TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w800)),
                const SizedBox(height: 6),
                const Text('Votre argent, simplement.', style: TextStyle(color: Colors.white60)),
                const SizedBox(height: 36),
                TextField(
                    controller: _u,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(labelText: 'E-mail ou nom d\'utilisateur', prefixIcon: Icon(Icons.person_outline))),
                const SizedBox(height: 14),
                TextField(
                    controller: _p,
                    obscureText: _hide,
                    onSubmitted: (_) => _go(),
                    decoration: InputDecoration(
                        labelText: 'Mot de passe',
                        prefixIcon: const Icon(Icons.lock_outline),
                        suffixIcon: IconButton(
                            icon: Icon(_hide ? Icons.visibility_off : Icons.visibility),
                            onPressed: () => setState(() => _hide = !_hide)))),
                const SizedBox(height: 24),
                SizedBox(
                    width: double.infinity,
                    height: 52,
                    child: FilledButton(
                      style: FilledButton.styleFrom(backgroundColor: kAccent, foregroundColor: kNavy),
                      onPressed: _busy ? null : _go,
                      child: _busy
                          ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5))
                          : const Text('Se connecter', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                    )),
              ]),
            ),
          ),
        ),
      );
}

// ---------- Navigation principale ----------
class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _i = 0;
  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
            child: IndexedStack(index: _i, children: [
          HomePage(go: (i) => setState(() => _i = i)),
          const CardsPage(),
          const ShopPage(),
          const ProfilePage(),
        ])),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _i,
          onDestinationSelected: (i) => setState(() => _i = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Accueil'),
            NavigationDestination(icon: Icon(Icons.credit_card_outlined), selectedIcon: Icon(Icons.credit_card), label: 'Cartes'),
            NavigationDestination(icon: Icon(Icons.storefront_outlined), selectedIcon: Icon(Icons.storefront), label: 'Boutique'),
            NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profil'),
          ],
        ),
      );
}

// ---------- Composants ----------
class Line extends StatelessWidget {
  final IconData icon;
  final String title, sub, right;
  final String? badge;
  final Color color;
  const Line({super.key, required this.icon, required this.title, required this.sub, required this.right, this.badge, this.color = kNavy});
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
        child: Row(children: [
          CircleAvatar(backgroundColor: color.withOpacity(.1), child: Icon(icon, color: color, size: 20)),
          const SizedBox(width: 12),
          Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
            Text(sub, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.grey, fontSize: 12)),
          ])),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(right, style: const TextStyle(fontWeight: FontWeight.w700)),
            if (badge != null) Text(badge!, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w600)),
          ]),
        ]),
      );
}

class CardFace extends StatelessWidget {
  final VCard c;
  final double balance;
  const CardFace({super.key, required this.c, required this.balance});
  @override
  Widget build(BuildContext context) => Container(
        height: 190,
        margin: const EdgeInsets.only(bottom: 14),
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: LinearGradient(
              colors: c.enabled ? const [kNavy, Color(0xFF5B2A86)] : [Colors.grey.shade700, Colors.grey.shade500],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight),
          boxShadow: [BoxShadow(color: kNavy.withOpacity(.25), blurRadius: 16, offset: const Offset(0, 8))],
        ),
        child: Column(mainAxisAlignment: MainAxisAlignment.spaceBetween, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('PaysenP', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 18)),
            Icon(Icons.contactless, color: Colors.white70),
          ]),
          Text(c.maskedPan.isNotEmpty ? c.maskedPan : '•••• •••• •••• ${c.last4}',
              style: const TextStyle(color: Colors.white, fontSize: 20, letterSpacing: 2, fontWeight: FontWeight.w500)),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, crossAxisAlignment: CrossAxisAlignment.end, children: [
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Solde', style: TextStyle(color: Colors.white60, fontSize: 12)),
              Text(money(balance, c.currency.isEmpty ? 'USD' : c.currency),
                  style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w700)),
            ]),
            Text(c.enabled ? 'ACTIVE' : 'BLOQUÉE', style: TextStyle(color: c.enabled ? kAccent : Colors.white70, fontWeight: FontWeight.w700)),
          ]),
        ]),
      );
}

// ---------- Accueil ----------
class HomePage extends StatelessWidget {
  final void Function(int) go;
  const HomePage({super.key, required this.go});

  Widget _action(IconData i, String l, VoidCallback f) => Expanded(
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: f,
          child: Container(
              padding: const EdgeInsets.symmetric(vertical: 16),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
              child: Column(children: [Icon(i, color: kAccent), const SizedBox(height: 6), Text(l, style: const TextStyle(fontWeight: FontWeight.w600))])),
        ),
      );

  @override
  Widget build(BuildContext context) => Load<Dashboard>(
        fetch: ApiClient.I.dashboard,
        build: (c, d, reload) {
          final w = d.main;
          final first = d.user.fullname.split(' ').first;
          return RefreshIndicator(
            onRefresh: reload,
            child: ListView(padding: const EdgeInsets.all(20), children: [
              Text('Bonjour${first.isEmpty ? '' : ', $first'} 👋', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: kNavy)),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(24),
                    gradient: const LinearGradient(colors: [kNavy, Color(0xFF1E3A8A)], begin: Alignment.topLeft, end: Alignment.bottomRight)),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Solde disponible', style: TextStyle(color: Colors.white70)),
                  const SizedBox(height: 8),
                  Text(money(w?.balance ?? 0, w?.code ?? 'USD'), style: const TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.w800)),
                  for (final x in d.wallets.skip(1)) Padding(padding: const EdgeInsets.only(top: 6), child: Text(money(x.balance, x.code), style: const TextStyle(color: kAccent, fontWeight: FontWeight.w600))),
                ]),
              ),
              const SizedBox(height: 16),
              Row(children: [
                _action(Icons.credit_card, 'Mes cartes', () => go(1)),
                const SizedBox(width: 12),
                _action(Icons.storefront, 'Boutique', () => go(2)),
              ]),
              const SizedBox(height: 24),
              const Text('Transactions récentes', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: kNavy)),
              const SizedBox(height: 12),
              if (d.recent.isEmpty) const Padding(padding: EdgeInsets.all(20), child: Center(child: Text('Aucune transaction pour le moment', style: TextStyle(color: Colors.grey)))),
              for (final t in d.recent)
                Line(
                    icon: Icons.swap_horiz,
                    title: pretty(t.type),
                    sub: '${fmtDate(t.createdAt)} • ${t.trxId}',
                    right: money(t.payable, t.currency.isEmpty ? 'USD' : t.currency),
                    badge: txStatus(t.status).$1,
                    color: txStatus(t.status).$2),
            ]),
          );
        },
      );
}

// ---------- Cartes ----------
class CardsPage extends StatelessWidget {
  const CardsPage({super.key});
  @override
  Widget build(BuildContext context) => Load<List<VCard>>(
        fetch: ApiClient.I.cards,
        build: (c, list, reload) => RefreshIndicator(
          onRefresh: reload,
          child: ListView(padding: const EdgeInsets.all(20), children: [
            const Text('Mes cartes', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: kNavy)),
            const SizedBox(height: 16),
            if (list.isEmpty) const Padding(padding: EdgeInsets.all(32), child: Center(child: Text('Aucune carte virtuelle', style: TextStyle(color: Colors.grey)))),
            for (final k in list)
              GestureDetector(
                onTap: () async {
                  await Navigator.push(c, MaterialPageRoute(builder: (_) => CardPage(card: k)));
                  reload();
                },
                child: CardFace(c: k, balance: k.balance),
              ),
          ]),
        ),
      );
}

class CardPage extends StatefulWidget {
  final VCard card;
  const CardPage({super.key, required this.card});
  @override
  State<CardPage> createState() => _CardPageState();
}

class _CardPageState extends State<CardPage> {
  late double _bal = widget.card.balance;
  int _rev = 0;

  Future<void> _money(bool dep) async {
    final r = await showModalBottomSheet<CardTxResult>(
        context: context, isScrollControlled: true, backgroundColor: Colors.transparent, builder: (_) => MoneySheet(card: widget.card, deposit: dep));
    if (r == null || !mounted) return;
    setState(() {
      _bal = r.cardBalance;
      _rev++;
    });
    toast(context, '${dep ? 'Dépôt' : 'Retrait'} effectué • réf. ${r.trxId}');
  }

  Future<void> _details() async {
    final pw = TextEditingController();
    final ok = await showDialog<bool>(
        context: context,
        builder: (d) => AlertDialog(
              title: const Text('Confirmez votre identité'),
              content: TextField(controller: pw, obscureText: true, autofocus: true, decoration: const InputDecoration(labelText: 'Mot de passe')),
              actions: [
                TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Annuler')),
                FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Afficher')),
              ],
            ));
    if (ok != true || pw.text.isEmpty) return;
    try {
      final d = await ApiClient.I.cardDetails(widget.card.ref, pw.text);
      if (!mounted) return;
      showDialog(context: context, builder: (_) => DetailsDialog(d: d));
    } catch (e) {
      if (mounted) toast(context, errMsg(e), error: true);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Ma carte', style: TextStyle(fontWeight: FontWeight.w700))),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          CardFace(c: widget.card, balance: _bal),
          Row(children: [
            Expanded(child: FilledButton.icon(onPressed: widget.card.enabled ? () => _money(true) : null, icon: const Icon(Icons.add), label: const Text('Déposer'))),
            const SizedBox(width: 12),
            Expanded(child: OutlinedButton.icon(onPressed: widget.card.enabled ? () => _money(false) : null, icon: const Icon(Icons.remove), label: const Text('Retirer'))),
          ]),
          const SizedBox(height: 12),
          FilledButton.tonalIcon(onPressed: _details, icon: const Icon(Icons.visibility_outlined), label: const Text('Afficher les détails de la carte')),
          const SizedBox(height: 24),
          const Text('Transactions', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: kNavy)),
          const SizedBox(height: 12),
          Load<List<VCardTx>>(
            key: ValueKey(_rev),
            fetch: () => ApiClient.I.cardTransactions(widget.card.ref),
            build: (c, list, _) => list.isEmpty
                ? const Padding(padding: EdgeInsets.all(20), child: Center(child: Text('Aucune transaction', style: TextStyle(color: Colors.grey))))
                : Column(children: [
                    for (final t in list)
                      Line(
                          icon: t.isDebit ? Icons.arrow_upward : Icons.arrow_downward,
                          title: t.description.isNotEmpty ? t.description : (t.merchant.isNotEmpty ? t.merchant : pretty(t.type)),
                          sub: fmtDate(t.createdAt),
                          right: '${t.isDebit ? '-' : '+'}${money(t.amount)}',
                          badge: t.status,
                          color: t.isDebit ? Colors.red : Colors.green),
                  ]),
          ),
        ]),
      );
}

class DetailsDialog extends StatelessWidget {
  final VCardDetails d;
  const DetailsDialog({super.key, required this.d});

  Widget _row(BuildContext c, String k, String v, {String? copy}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(k, style: const TextStyle(color: Colors.grey, fontSize: 12)),
            Text(v, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700, letterSpacing: 1)),
          ])),
          if (copy != null)
            IconButton(
                icon: const Icon(Icons.copy, size: 20),
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: copy));
                  toast(c, 'Copié');
                }),
        ]),
      );

  @override
  Widget build(BuildContext context) => AlertDialog(
        title: const Text('Détails de la carte'),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          _row(context, 'Titulaire', d.name),
          _row(context, 'Numéro', d.spacedNumber, copy: d.number),
          _row(context, 'Expiration', d.expiry),
          _row(context, 'CVV', d.cvv, copy: d.cvv),
          const SizedBox(height: 8),
          const Text('Ne partagez jamais ces informations.', style: TextStyle(color: Colors.red, fontSize: 12)),
        ]),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Fermer'))],
      );
}

// ---------- Dépôt / Retrait (aperçu puis confirmation) ----------
class MoneySheet extends StatefulWidget {
  final VCard card;
  final bool deposit;
  const MoneySheet({super.key, required this.card, required this.deposit});
  @override
  State<MoneySheet> createState() => _MoneySheetState();
}

class _MoneySheetState extends State<MoneySheet> {
  final _a = TextEditingController();
  CardPreview? _pv;
  bool _busy = false;
  String? _err;

  double get _amt => double.tryParse(_a.text.replaceAll(',', '.')) ?? 0;

  Future<void> _run() async {
    if (_amt <= 0) {
      setState(() => _err = 'Saisissez un montant valide');
      return;
    }
    setState(() {
      _busy = true;
      _err = null;
    });
    try {
      final api = ApiClient.I, id = widget.card.id;
      if (_pv == null) {
        _pv = widget.deposit ? await api.cardDepositPreview(id, _amt) : await api.cardWithdrawPreview(id, _amt);
      } else {
        final r = widget.deposit ? await api.cardDeposit(id, _amt) : await api.cardWithdraw(id, _amt);
        if (mounted) Navigator.pop(context, r);
      }
    } catch (e) {
      _err = errMsg(e);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _kv(String k, String v, {bool bold = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(k, style: const TextStyle(color: Colors.grey)),
          Text(v, style: TextStyle(fontWeight: bold ? FontWeight.w800 : FontWeight.w500, fontSize: bold ? 17 : 14)),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    final pv = _pv;
    return Container(
      padding: EdgeInsets.fromLTRB(24, 20, 24, 24 + MediaQuery.of(context).viewInsets.bottom),
      decoration: const BoxDecoration(color: kBg, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(widget.deposit ? 'Déposer sur la carte' : 'Retirer de la carte', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: kNavy)),
        const SizedBox(height: 16),
        TextField(
          controller: _a,
          enabled: !_busy,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          onChanged: (_) => setState(() {
            _pv = null;
            _err = null;
          }),
          decoration: InputDecoration(labelText: 'Montant', suffixText: 'USD', helperText: widget.deposit ? null : 'Minimum 5 USD'),
        ),
        if (pv != null) ...[
          const SizedBox(height: 16),
          Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)),
              child: Column(children: [
                _kv('Montant', money(pv.amount, pv.cardCurrency)),
                _kv('Frais', money(pv.totalCharge, pv.fromCurrency)),
                const Divider(),
                _kv(widget.deposit ? 'Total débité du portefeuille' : 'Crédité au portefeuille', money(pv.payable, pv.fromCurrency), bold: true),
              ])),
        ],
        if (_err != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(_err!, style: TextStyle(color: Colors.red.shade700))),
        const SizedBox(height: 18),
        bigBtn(pv == null ? 'Voir l\'aperçu' : 'Confirmer ${widget.deposit ? 'le dépôt' : 'le retrait'}', _run, busy: _busy),
      ]),
    );
  }
}

// ---------- Boutique (catalogue) ----------
class ShopPage extends StatelessWidget {
  const ShopPage({super.key});
  @override
  Widget build(BuildContext context) => Load<List<Product>>(
        fetch: ApiClient.I.products,
        build: (c, list, reload) => RefreshIndicator(
          onRefresh: reload,
          child: ListView(padding: const EdgeInsets.all(20), children: [
            const Text('Boutique', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: kNavy)),
            const SizedBox(height: 16),
            if (list.isEmpty) const Center(child: Text('Aucun produit disponible', style: TextStyle(color: Colors.grey))),
            for (final p in list)
              Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
                child: Row(children: [
                  ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: p.image.isEmpty
                          ? Container(width: 72, height: 72, color: kBg, child: const Icon(Icons.image_not_supported_outlined))
                          : Image.network(p.image, width: 72, height: 72, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(width: 72, height: 72, color: kBg, child: const Icon(Icons.broken_image_outlined)))),
                  const SizedBox(width: 14),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(p.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
                    if (p.category.isNotEmpty) Text(p.category, style: const TextStyle(color: Colors.grey, fontSize: 12)),
                    const SizedBox(height: 4),
                    Text(p.price.toStringAsFixed(2), style: const TextStyle(color: kNavy, fontWeight: FontWeight.w800, fontSize: 16)),
                  ])),
                  Text(p.totalStock > 0 ? 'En stock' : 'Épuisé', style: TextStyle(color: p.totalStock > 0 ? Colors.green : Colors.red, fontSize: 12, fontWeight: FontWeight.w600)),
                ]),
              ),
          ]),
        ),
      );
}

// ---------- Profil ----------
class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  String _kyc(int k) => switch (k) { 1 => 'Identité vérifiée', 2 => 'Vérification en cours', 3 => 'Vérification rejetée', _ => 'Identité non vérifiée' };

  @override
  Widget build(BuildContext context) => Load<Dashboard>(
        fetch: ApiClient.I.dashboard,
        build: (c, d, reload) {
          final u = d.user;
          return ListView(padding: const EdgeInsets.all(20), children: [
            const SizedBox(height: 12),
            Center(child: CircleAvatar(radius: 40, backgroundColor: kNavy, child: Text(u.fullname.isNotEmpty ? u.fullname[0].toUpperCase() : 'P', style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w700)))),
            const SizedBox(height: 14),
            Center(child: Text(u.fullname, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: kNavy))),
            Center(child: Text(u.email, style: const TextStyle(color: Colors.grey))),
            const SizedBox(height: 24),
            Line(icon: Icons.alternate_email, title: 'Nom d\'utilisateur', sub: u.username, right: ''),
            Line(icon: Icons.verified_user_outlined, title: 'Statut KYC', sub: _kyc(u.kycVerified), right: '', color: u.kycVerified == 1 ? Colors.green : Colors.orange),
            const SizedBox(height: 20),
            OutlinedButton.icon(
                style: OutlinedButton.styleFrom(foregroundColor: Colors.red, minimumSize: const Size.fromHeight(52), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
                onPressed: () => signOut(context),
                icon: const Icon(Icons.logout),
                label: const Text('Se déconnecter')),
          ]);
        },
      );
}
